-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- ����: localhost
-- ����� ��������: ��� 13 2011 �., 12:23
-- ������ �������: 5.0.18
-- ������ PHP: 5.1.6
-- 
-- ��: `socialarti`
-- 

-- --------------------------------------------------------

-- 
-- ��������� ������� `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(16) NOT NULL default '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- 
-- ���� ������ ������� `ci_sessions`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `comments`
-- 

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL auto_increment,
  `id_mnews` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `text` text collate utf8_bin NOT NULL,
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id_comment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4 ;

-- 
-- ���� ������ ������� `comments`
-- 

INSERT INTO `comments` VALUES (1, 13, 3, 0xf2e5f1f2e8f0eee2e0ede8e520eaeeecece5edf2e0f0e8ff212121, '2011-01-13 11:44:31');
INSERT INTO `comments` VALUES (2, 13, 2, 0xeff0e8e2e5f220ece8f021, '2011-01-13 11:51:19');
INSERT INTO `comments` VALUES (3, 13, 2, 0xf3e3f3eaf120e2f1e520f0e0e1eef2e0e5f229, '2011-01-13 11:53:41');

-- --------------------------------------------------------

-- 
-- ��������� ������� `friends`
-- 

CREATE TABLE `friends` (
  `id_zapr` int(11) NOT NULL auto_increment,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `text` varchar(500) collate utf8_bin NOT NULL default ' ',
  `accept` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id_zapr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

-- 
-- ���� ������ ������� `friends`
-- 

INSERT INTO `friends` VALUES (1, 3, 2, 0x20f2e5f1f2e8f0eee2e0ede8e520e4f0f3e7e5e92121, 1);
INSERT INTO `friends` VALUES (2, 2, 4, 0xeff0e8e2e5f220fdf2ee20ff20c0f0f2e5ec21, 1);

-- --------------------------------------------------------

-- 
-- ��������� ������� `message`
-- 

CREATE TABLE `message` (
  `id_message` int(11) NOT NULL auto_increment,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `text` text collate utf8_bin NOT NULL,
  `read` int(11) NOT NULL default '0',
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id_message`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=12 ;

-- 
-- ���� ������ ������� `message`
-- 

INSERT INTO `message` VALUES (1, 3, 2, 0xd2e5f1f2e8f0eee2e0ede8e520, 1, '2011-01-11 16:47:44');
INSERT INTO `message` VALUES (2, 3, 2, 0x736466736466736466, 1, '2011-01-11 16:45:46');
INSERT INTO `message` VALUES (3, 3, 2, 0xe5f9e520eee4edee20f2e8efee20f2e5f1f2e8f0eee2e0ede8ff2121, 1, '2011-01-11 16:24:50');
INSERT INTO `message` VALUES (4, 3, 2, 0xeff0e8e2e5f220f7f3e2e0ea20eae0ea20e6e8e7edfc20293f, 1, '2011-01-11 16:24:17');
INSERT INTO `message` VALUES (5, 2, 2, 0xeef2e2e5f220ede020f1eeeee1f9e5ede8e52e2e2e2e2e, 1, '2011-01-11 16:49:04');
INSERT INTO `message` VALUES (6, 2, 2, 0xeef2e2e5f220ede020f1eeeee1f9e5ede8e520e4f3e1ebfc20e4e2e021, 1, '2011-01-11 16:48:57');
INSERT INTO `message` VALUES (7, 2, 2, 0xeef2eff0e0e2eae020e0f0f2e5ecf320ebe5e1e5e4e5e2f3f3212121, 1, '2011-01-11 16:50:22');
INSERT INTO `message` VALUES (8, 2, 2, 0xf2e5f1f2e8f0eee2e0ede8e8e5e5e5e521, 1, '2011-01-11 16:54:42');
INSERT INTO `message` VALUES (9, 2, 3, 0xe0e3e020f2e5f1f2e8f0eee2e0ede8e5e5e5e5212121, 0, '2011-01-11 16:54:58');
INSERT INTO `message` VALUES (10, 2, 3, 0xeff0e8e2e5f220f7f3e2e0ea29, 0, '2011-01-11 16:55:25');
INSERT INTO `message` VALUES (11, 2, 3, 0xe0e3e020eff0e8e2e5f2, 0, '2011-01-11 18:40:26');

-- --------------------------------------------------------

-- 
-- ��������� ������� `micronews`
-- 

CREATE TABLE `micronews` (
  `id_mnews` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `text` text collate utf8_bin NOT NULL,
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id_mnews`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=24 ;

-- 
-- ���� ������ ������� `micronews`
-- 

INSERT INTO `micronews` VALUES (1, 3, 0xcfe5f0e2e0ff204d6963726f6e65777321, '2011-01-10 21:28:17');
INSERT INTO `micronews` VALUES (2, 2, 0xd5e5f520736f6369616c4172746920f0e0e1eef2e0e5f2292920, '2011-01-10 22:03:32');
INSERT INTO `micronews` VALUES (3, 2, 0xcfe5f0e2e0ff20e7e0efe8f1fc20f2e8efee2e2e2e, '2011-01-10 22:05:48');
INSERT INTO `micronews` VALUES (4, 3, 0xc2f2eef0e0ff20e7e0efe8f1fc20f2e8efee2e2e2e2e2e, '2011-01-10 22:06:02');
INSERT INTO `micronews` VALUES (5, 2, 0xf1f2e0f2f3f120e220cce8eaf0ee4e6577732121, '2011-01-10 22:43:47');
INSERT INTO `micronews` VALUES (6, 2, 0xe2f1e520eef5f3e5edededeeeeeeee2020f1ebf3f8e0fe204c6f72646921, '2011-01-10 22:44:28');
INSERT INTO `micronews` VALUES (7, 2, 0xefeee9e4f320f9e020d3ede8e2e5f020f120e8edf2e5f0ede0ece820efeef1eceef2f0fe20e820ede0e2e5f0edeee520f1efe0f2fc292929, '2011-01-10 22:54:49');
INSERT INTO `micronews` VALUES (8, 3, 0xefe8f8f320f1e8f1f2e5ecf320ebe8f7edfbf520f1eeeee1f9e5ede8e920eaf0f3f2ee3f29, '2011-01-11 13:15:47');
INSERT INTO `micronews` VALUES (9, 2, 0xf2e5f1f2e8f0f3fe20f1e8f1f2e5ecf320ebe8f7edfbf520f1eeeee1f9e5ede8e929290a, '2011-01-11 16:55:40');
INSERT INTO `micronews` VALUES (10, 2, 0xf4f3f420f1e8f1f2e5ecf320ebe8f7edfbf520f1eeeee1f9e5ede8e920e2f0eee4e520ede0efe8f1e0eb2e20ede0e4ee20ede0e2e5f0edeee520ede0f7e8ede0f2fc20efe8f1e0f2fc20eaeeecece5edf2e0f0e8e820ea20ece8eaf0ee6e657773, '2011-01-11 17:37:14');
INSERT INTO `micronews` VALUES (11, 4, 0xcfeee4f0f3e6e8ebf1ff20f120edeee2fbec20efeeebfce7eee2e0f2e5ebe5ec2121, '2011-01-11 19:52:41');
INSERT INTO `micronews` VALUES (12, 2, 0xcee1edeee2e8eb20eaeeedf2e0eaf2edfbe520e4e0ededfbe521, '2011-01-12 13:25:31');
INSERT INTO `micronews` VALUES (13, 2, 0xcee1edeee2e8eb20eaeeedf2e0eaf2edfbe520e4e0ededfbe521, '2011-01-12 13:26:11');
INSERT INTO `micronews` VALUES (14, 5, 0xcff0e5e2e5e420ece8f029, '2011-01-12 13:32:35');
INSERT INTO `micronews` VALUES (15, 5, 0xcff0e5e2e5e420ece8f029, '2011-01-12 13:32:42');
INSERT INTO `micronews` VALUES (16, 5, 0xcff0e5e2e5e420ece8f029, '2011-01-12 13:33:17');
INSERT INTO `micronews` VALUES (17, 5, 0xcff0e5e2e5e420ece8f029, '2011-01-12 13:35:34');
INSERT INTO `micronews` VALUES (18, 5, 0xe8f1eff0e0e2ebe5ed20e5f9e520eee4e8ed20e1e0e32920eaf0f3f2ee2129, '2011-01-12 13:41:12');
INSERT INTO `micronews` VALUES (19, 2, 0xe8f1eff0e0e2ebe5ede8e520e1e0e3eee220f5db, '2011-01-13 12:04:01');
INSERT INTO `micronews` VALUES (20, 2, 0xf2e5f1f2e8f0eee2e0ede8e521, '2011-01-13 12:04:21');
INSERT INTO `micronews` VALUES (21, 2, 0xf2e5f1f2e8f0eee2e0ede8e520f1f2e0f2f3f1e021, '2011-01-13 12:05:36');
INSERT INTO `micronews` VALUES (22, 2, 0xe5f9e520eee4edee20f2e5f1f2e8f0eee2e0ede8e52121, '2011-01-13 12:06:30');
INSERT INTO `micronews` VALUES (23, 2, 0xf2e5f1f2e82e2e2e2e2ef0ee2e2e2ee2e02e2e2e2eede8e5, '2011-01-13 12:07:05');

-- --------------------------------------------------------

-- 
-- ��������� ������� `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) collate utf8_bin NOT NULL,
  `password` varchar(255) collate utf8_bin NOT NULL,
  `last_login` int(11) NOT NULL default '0',
  `profile` text collate utf8_bin NOT NULL,
  `nick` varchar(200) collate utf8_bin default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nick` (`nick`),
  FULLTEXT KEY `profile` (`profile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

-- 
-- ���� ������ ������� `users`
-- 

INSERT INTO `users` VALUES (3, 0x6d617a79725f3931406d61696c2e7275, 0x6437666564313431616133326139663764303762303136653565343032326239, 1294753133, 0x613a383a7b733a343a226e616d65223b733a373a224c656265646576223b733a373a227375726e616d65223b733a353a22417274656d223b733a343a226f746368223b733a31313a2254617469616e6f76696368223b733a343a2266726f6d223b733a363a224d6f73636f77223b733a333a22696371223b733a31393a22ede520f3eae0e7e0ede0223b733a363a226a6162626572223b733a31373a22ede520f3eae0e7e0ed223b733a353a22736b797065223b733a31373a22ede520f3eae0e7e0ed223b733a363a22737461747573223b733a36383a22efe8f8f320f1e8f1f2e5ecf320ebe8f7edfbf520f1eeeee1f9e5ede8e920eaf0f3f2ee3f29223b7d, 0x6c656265646576);
INSERT INTO `users` VALUES (2, 0x7370616d406d69722d73617261746f762e7275, 0x6437666564313431616133326139663764303762303136653565343032326239, 1294907622, 0x613a393a7b733a343a226e616d65223b733a353a22417274656d223b733a373a227375726e616d65223b733a393a225461746172696e6f76223b733a343a226f746368223b733a393a2249676f726576696368223b733a343a2266726f6d223b733a373a2253617261746f76223b733a363a22737461747573223b733a33363a22f2e5f1f2e82e2e2e2e2ef0ee2e2e2ee2e02e2e2e2eede8e5223b733a353a2270686f746f223b733a353a22322e6a7067223b733a333a22696371223b733a363a22323637313733223b733a353a22736b797065223b733a393a22696e6b6f676e697435223b733a363a226a6162626572223b733a32333a226261636b646f6f72406d69722d73617261746f762e7275223b7d, 0x7461746172696e6f76);
INSERT INTO `users` VALUES (4, 0x6f6c65736961406d69722d73617261746f762e7275, 0x6531306164633339343962613539616262653536653035376632306638383365, 1294763584, 0x613a373a7b733a343a226e616d65223b733a363a224f6c65736961223b733a373a227375726e616d65223b733a31303a225461746172696e6f7661223b733a343a226f746368223b733a383a2249676f7265766e61223b733a343a2266726f6d223b733a373a2253617261746f76223b733a333a22696371223b733a31393a22ede520f3eae0e7e0ede0223b733a363a226a6162626572223b733a31373a22ede520f3eae0e7e0ed223b733a353a22736b797065223b733a31373a22ede520f3eae0e7e0ed223b7d, NULL);
INSERT INTO `users` VALUES (5, 0x7465737465724079612e7275, 0x6531306164633339343962613539616262653536653035376632306638383365, 1294828298, 0x613a393a7b733a343a226e616d65223b733a343a224976616e223b733a373a227375726e616d65223b733a363a22546573746572223b733a343a226f746368223b733a383a22416e6174616c696f223b733a343a2266726f6d223b733a343a224b656976223b733a333a22696371223b733a31393a22ede520f3eae0e7e0ede0223b733a363a226a6162626572223b733a31373a22ede520f3eae0e7e0ed223b733a353a22736b797065223b733a31373a22ede520f3eae0e7e0ed223b733a363a22737461747573223b733a35353a22e8f1eff0e0e2ebe5ed20e5f9e520eee4e8ed20e1e0e32920eaf0f3f2ee2129223b733a353a2270686f746f223b733a353a22352e6a7067223b7d, NULL);
